#include "mpib_p2p_benchmarks.h"
#include "p2p/mpib_p2p.h"
#include "mpib_defs.h"
#include <malloc.h>

#include "mpib_computation.h"

class MPIB_roundtrip_container: public MPIB_p2p_container {
private:
	char* buffer;
public:
	MPIB_roundtrip_container() {
		MPIB_p2p_container::operation = "roundtrip";
		MPIB_p2p_container::initialize = initialize;
		MPIB_p2p_container::execute_measure = execute_measure;
		MPIB_p2p_container::execute_mirror = execute_mirror;
		MPIB_p2p_container::finalize = finalize;

		/* RICO: */
		/* Overhead */
		MPIB_p2p_container::execute_measure_o_eager = execute_measure_o_eager;
		MPIB_p2p_container::execute_mirror_o        = execute_mirror_o;
    MPIB_p2p_container::execute_measure_o_rndv  = execute_measure_o_rndv;
    /* Transfer time */
		MPIB_p2p_container::execute_measure_Tm          = execute_measure_Tm;
		MPIB_p2p_container::execute_mirror_Tm           = execute_mirror_Tm;
    MPIB_p2p_container::execute_measure_Tm_PingPong = execute_measure_Tm_PingPong;
    MPIB_p2p_container::execute_mirror_Tm_PingPong  = execute_mirror_Tm_PingPong;
		/* Gamma */
    MPIB_p2p_container::execute_measure_Gamma = execute_measure_Gamma;
	}

	static void initialize(void* _this, MPI_Comm comm, int M) {
		MPIB_roundtrip_container* container = (MPIB_roundtrip_container*)_this;
		container->buffer = (char*)malloc(sizeof(char) * M);
	}

	static void execute_measure(void* _this, MPI_Comm comm, int M, int mirror) {
		MPIB_roundtrip_container* container = (MPIB_roundtrip_container*)_this;
		MPIB_Send(container->buffer, M, MPI_CHAR, mirror, 0, comm);
		MPIB_Recv(container->buffer, M, MPI_CHAR, mirror, 0, comm, MPI_STATUS_IGNORE);
	}

	static void execute_mirror(void* _this, MPI_Comm comm, int M, int measure) {
		MPIB_roundtrip_container* container = (MPIB_roundtrip_container*)_this;
		MPIB_Recv(container->buffer, M, MPI_CHAR, measure, 0, comm, MPI_STATUS_IGNORE);
		MPIB_Send(container->buffer, M, MPI_CHAR, measure, 0, comm);
	}

	static void finalize(void* _this, MPI_Comm comm) {
		MPIB_roundtrip_container* container = (MPIB_roundtrip_container*)_this;
		free(container->buffer);
	}

	/* RICO:  */
	/* Overhead: */
	static void execute_measure_o_eager(void* _this, MPI_Comm comm, int M, int mirror) {
		MPIB_roundtrip_container* container = (MPIB_roundtrip_container*)_this;
		MPI_Send(container->buffer, 0, MPI_BYTE, mirror, 0, comm);
		//MPI_Rsend(container->buffer, 0, MPI_BYTE, mirror, 0, comm);
	}

	static void execute_mirror_o(void* _this, MPI_Comm comm, int M, int measure) {
		MPIB_roundtrip_container* container = (MPIB_roundtrip_container*)_this;
		MPI_Recv(container->buffer, 0, MPI_BYTE, measure, 0, comm, MPI_STATUS_IGNORE);
	}

	static void execute_measure_o_rndv(void* _this, MPI_Comm comm, int M, int mirror) {
		MPIB_roundtrip_container* container = (MPIB_roundtrip_container*)_this;
		MPI_Ssend(container->buffer, 0, MPI_BYTE, mirror, 0, comm);
				//MPI_Rsend(container->buffer, 0, MPI_BYTE, mirror, 0, comm);
	}

	/* Transfer time */
	static void execute_measure_Tm(void* _this, MPI_Comm comm, int M, int dest, int source) {
		MPIB_roundtrip_container* container = (MPIB_roundtrip_container*)_this;
		MPI_Sendrecv(container->buffer, M, MPI_BYTE, dest, 0, container->buffer, M, MPI_BYTE, source, 0, comm, MPI_STATUS_IGNORE);
	}

	static void execute_mirror_Tm(void* _this, MPI_Comm comm, int M, int dest, int source) {
		MPIB_roundtrip_container* container = (MPIB_roundtrip_container*)_this;
		MPI_Sendrecv(container->buffer, M, MPI_BYTE, dest, 0, container->buffer, M, MPI_BYTE, source, 0, comm, MPI_STATUS_IGNORE);
	}

   static void execute_measure_Tm_PingPong(void* _this, MPI_Comm comm, int M, int mirror) {
      MPIB_roundtrip_container* container = (MPIB_roundtrip_container*)_this;
      MPI_Send(container->buffer, M, MPI_BYTE, mirror, 0, comm);
      MPI_Recv(container->buffer, M, MPI_BYTE, mirror, 0, comm, MPI_STATUS_IGNORE);
      //MPI_Rsend(container->buffer, 0, MPI_BYTE, mirror, 0, comm);
   }

   static void execute_mirror_Tm_PingPong(void* _this, MPI_Comm comm, int M, int measure) {
      MPIB_roundtrip_container* container = (MPIB_roundtrip_container*)_this;
      MPI_Recv(container->buffer, M, MPI_BYTE, measure, 0, comm, MPI_STATUS_IGNORE);
      MPI_Send(container->buffer, M, MPI_BYTE, measure, 0, comm);
   }

   /* Gamma */
	 static void execute_measure_Gamma(void* _this, MPI_Comm comm, int M, int op, void *a, void *b) {
      MPIB_roundtrip_container* container = (MPIB_roundtrip_container*)_this;
      //MPI_Send(container->buffer, M, MPI_BYTE, mirror, 0, comm);
      //MPI_Recv(container->buffer, M, MPI_BYTE, mirror, 0, comm, MPI_STATUS_IGNORE);
      //MPI_Rsend(container->buffer, 0, MPI_BYTE, mirror, 0, comm);
			//integer_op (M, ompi_op_base_2buff_min_int32_t, a, b);
			measure_op (M, op, a, b);			
   }

};

extern "C" MPIB_p2p_container* MPIB_roundtrip_container_alloc() {
	return new MPIB_roundtrip_container();
}

extern "C" void MPIB_roundtrip_container_free(MPIB_p2p_container* container) {
	delete container;
}
