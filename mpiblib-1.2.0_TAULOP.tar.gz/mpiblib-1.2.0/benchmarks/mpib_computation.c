
#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>
#include <stdlib.h>
#include "mpi.h"

#include "mpib.h"


void (*fxn_name[18]) (void *, void *, int *) = {
  ompi_op_base_2buff_max_int32_t,
  ompi_op_base_2buff_min_int32_t,
  ompi_op_base_2buff_sum_int32_t,
  ompi_op_base_2buff_prod_int32_t,
  ompi_op_base_2buff_land_int32_t,
  ompi_op_base_2buff_lor_int32_t,
  ompi_op_base_2buff_lxor_int32_t,
  ompi_op_base_2buff_band_int32_t,
  ompi_op_base_2buff_bor_int32_t,
  ompi_op_base_2buff_bxor_int32_t,
  ompi_op_base_2buff_maxloc_2int,
  ompi_op_base_2buff_minloc_2int,
  ompi_op_base_2buff_max_float,
  ompi_op_base_2buff_min_float,
  ompi_op_base_2buff_sum_float,
  ompi_op_base_2buff_prod_float,
  ompi_op_base_2buff_maxloc_float_int,
  ompi_op_base_2buff_minloc_float_int
};


/*
typedef struct { int v; int k; } ompi_op_predefined_2int_t;

static void ompi_op_base_2buff_maxloc_2int (const void *in, void *out, int *count) {
  int i;
  ompi_op_predefined_2int_t *a = (ompi_op_predefined_2int_t*) in;
  ompi_op_predefined_2int_t *b = (ompi_op_predefined_2int_t*) out;

  for (i = 0; i < *count; ++i, ++a, ++b) {

    if (a->v > b->v) {
      b->v = a->v;
      b->k = a->k;

    } else if (a->v == b->v) {
      b->k = (b->k < a->k ? b->k : a->k);
    }

  }
}
*/




void measure_op (int size, int op, void *a, void *b) {

   int count = size/sizeof(int32_t);

   fxn_name[op](a, b, &count);
}
