#include "mpib_p2p_benchmarks.h"
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include "mpib_output.h"
#include "mpib_utilities.h"
#include "mpib_computation.h"
#include <unistd.h>

int MPIB_check_comm_size(MPI_Comm comm) {
   int rank;
   MPI_Comm_rank(comm, &rank);
   int size;
   MPI_Comm_size(comm, &size);
   if (size < 2) {
      if (rank == 0)
         fprintf(stderr, "Cannot perform p2p benchmarks for %d processes (must be >= 2)\n", size);
      return -1;
   }
   return 0;
}

void MPIB_measure_p2p(MPIB_p2p_container* container, MPI_Comm comm, int measure, int mirror,
                      int M, MPIB_precision precision, MPIB_result* result) {
   if (MPIB_check_comm_size(comm))
      return;
   int rank;
   MPI_Comm_rank(comm, &rank);
   if (rank == measure || rank == mirror) {
      double* T = rank == measure ? (double*)malloc(sizeof(double) * precision.max_reps) : NULL;
      container->initialize(container, comm, M);
      int stop = 0;
      double sum = 0;
      int reps = 0;
      double ci = 0;
      while (!stop && reps < precision.max_reps) {
         if (rank == measure) {
            MPI_Recv(NULL, 0, MPI_CHAR, mirror, 0, comm, MPI_STATUS_IGNORE);
            T[reps] = MPI_Wtime();
            container->execute_measure(container, comm, M, mirror);
            sum += T[reps] = MPI_Wtime() - T[reps];
         }
         else {
            MPI_Send(NULL, 0, MPI_CHAR, measure, 0, comm);
            container->execute_mirror(container, comm, M, measure);
         }
         reps++;
         if (reps >= precision.min_reps && reps > 2) {
            if (rank == measure) {
               stop = (ci = MPIB_ci(precision.cl, reps, T)) * reps / sum < precision.eps;
               MPI_Send(&stop, 1, MPI_INT, mirror, 0, comm);
            }
            else
               MPI_Recv(&stop, 1, MPI_INT, measure, 0, comm, MPI_STATUS_IGNORE);
         }
      }
      container->finalize(container, comm);
      if (rank == measure)
         *result = (MPIB_result){M, sum / reps, MPI_Wtick(), reps, ci};
   }
}

void MPIB_measure_p2p_msgset(MPIB_p2p_container* container, MPI_Comm comm, int measure, int mirror,
                             MPIB_msgset msgset, MPIB_precision precision, int* count, MPIB_result** results)
{
   if (MPIB_check_comm_size(comm))
      return;
   int rank;
   MPI_Comm_rank(comm, &rank);
   if (rank == measure || rank == mirror) {
      if (rank == measure) {
         if (MPIB_verbose)
            fprintf(stderr, "adaptive p2p benchmark %d-%d:", measure, mirror);
         *count = 0;
         *results = NULL;
      }
      int M = msgset.min_size;
      int c = 0;
      // variables at measure
      double* T = NULL;
      double wtick = 0;
      int stride = msgset.min_stride; //adaptive stride
      int pos = 0;
      if (rank == measure) {
         // use the same array and wtick value for communication experiments with different message sizes
         T = (double*)malloc(sizeof(double) * precision.max_reps);
         wtick = MPI_Wtick();
      }
      /*
       In any case, we don't do more than max_size message sizes, but
       with the adaptive approach we also don't iterate more than max_num times
       */
      while (M <= msgset.max_size && !( (msgset.stride == 0) && (c > msgset.max_num))) {
         if ((rank == measure) && MPIB_verbose) {
            fprintf(stderr, " %d", M);
            fflush(stderr);
         }
         container->initialize(container, comm, M);
         int stop = 0;
         double sum = 0;
         int reps = 0;
         double ci = 0;
         /*
          This loop performs a number of repetitions with a fixed M. It runs while
          max(min_reps,2) < reps < max_reps) and NOT (ci * reps / sum ) < eps
          */
         while (!stop && reps < precision.max_reps) {
            if (rank == measure) {
               MPI_Recv(NULL, 0, MPI_CHAR, mirror, 0, comm, MPI_STATUS_IGNORE);
               T[reps] = MPI_Wtime();
               container->execute_measure(container, comm, M, mirror);
               sum += T[reps] = MPI_Wtime() - T[reps];
            }
            else {
               MPI_Send(NULL, 0, MPI_CHAR, measure, 0, comm);
               container->execute_mirror(container, comm, M, measure);
            }
            reps++;
            if (reps >= precision.min_reps && reps > 2) {
               if (rank == measure) {
                  stop = (ci = MPIB_ci(precision.cl, reps, T)) * reps / sum < precision.eps;
                  MPI_Send(&stop, 1, MPI_INT, mirror, 0, comm);
               }
               else
                  MPI_Recv(&stop, 1, MPI_INT, measure, 0, comm, MPI_STATUS_IGNORE);
            }
         }
         container->finalize(container, comm);
         c++;
         if (rank == measure) {
            MPIB_result result = (MPIB_result){M, sum / reps, wtick, reps, ci};
            *count = c;
            if (pos < c - 1) {
               MPIB_result* tmp = (MPIB_result*)malloc(sizeof(MPIB_result) * c);
               memcpy(tmp, *results, sizeof(MPIB_result) * pos);
               memcpy(&tmp[pos + 1], &(*results)[pos], sizeof(MPIB_result) * (c - 1 - pos));
               free(*results);
               *results = tmp;
            }
            else
               *results = (MPIB_result*)realloc(*results, sizeof(MPIB_result) * c);
            (*results)[pos] = result;
            /*
             determine the next M - adaptively or with fixed stride:
             if msgset.stride > 0, then use this fixed stride (non-adaptive)
             if msgset.stride == 0, increment M adaptively
             */
            if (msgset.stride == 0) {
               //adaptive M increment :
               do {
                  if (pos > 1 && (MPIB_diff(result, &(*results)[pos - 2]) < msgset.max_diff)) {
                     stride *= 2;
                     M += stride;
                     while (pos < c && (*results)[pos].M < M)
                        pos++;
                  } else {
                     if ((stride / 2) > msgset.min_stride) {
                        stride /= 2;
                        M -= stride;
                     } else {
                        M += stride;
                        while (pos < c && (*results)[pos].M < M)
                           pos++;
                     }
                  }
               } while (pos < c && (*results)[pos].M == M);
            } else {
               M += msgset.stride;
               pos++;
            }
            MPI_Send(&M, 1, MPI_INT, mirror, 0, comm);
         } else
            MPI_Recv(&M, 1, MPI_INT, measure, 0, comm, MPI_STATUS_IGNORE);
      }
      free(T);
      if ((rank == measure) && MPIB_verbose)
         fprintf(stderr, "\n\n");
   }
}

void MPIB_measure_allp2p(MPIB_p2p_container* container, MPI_Comm comm, int parallel,
                         int M, MPIB_precision precision, MPIB_result* results)
{
   if (MPIB_check_comm_size(comm))
      return;
   int rank;
   MPI_Comm_rank(comm, &rank);
   int size;
   MPI_Comm_size(comm, &size);
   int sendcount =  size - rank - 1;
   // results for pairs including a given processor
   MPIB_result* res = (MPIB_result*)malloc(sizeof(MPIB_result) * sendcount);
   // use the same array and wtick value for communication experiments with different pairs including a given processor
   double* T = (double*)malloc(sizeof(double) * precision.max_reps);
   double wtick = MPI_Wtick();
   container->initialize(container, comm, M);
   MPIB_pairs* pairs = MPIB_build_pairs(size);
   MPIB_pairs* iter_pairs = pairs;
   while (iter_pairs) {
      MPI_Barrier(comm);
      MPIB_pair* iter_pair = iter_pairs->list;
      while (iter_pair) {
         if (!parallel)
            MPI_Barrier(comm);
         int i = iter_pair->values[0];
         int j = iter_pair->values[1];
         if (rank == i || rank == j) {
            int stop = 0;
            double sum = 0;
            int reps = 0;
            double ci = 0;
            while (!stop && reps < precision.max_reps) {
               if (rank == i) {
                  MPI_Recv(NULL, 0, MPI_CHAR, j, 0, comm, MPI_STATUS_IGNORE);
                  T[reps] = MPI_Wtime();
                  container->execute_measure(container, comm, M, j);
                  sum += T[reps] = MPI_Wtime() - T[reps];
               }
               else {
                  MPI_Send(NULL, 0, MPI_CHAR, i, 0, comm);
                  container->execute_mirror(container, comm, M, i);
               }
               reps++;
               if (reps >= precision.min_reps && reps > 2) {
                  if (rank == i) {
                     stop = (ci = MPIB_ci(precision.cl, reps, T)) * reps / sum < precision.eps;
                     MPI_Send(&stop, 1, MPI_INT, j, 0, comm);
                  }
                  else
                     MPI_Recv(&stop, 1, MPI_INT, i, 0, comm, MPI_STATUS_IGNORE);
               }
            }
            if (rank == i)
               res[j - i - 1] = (MPIB_result){M, sum / reps, wtick, reps, ci};
         }
         iter_pair = iter_pair->next;
      }
      iter_pairs = iter_pairs->next;
   }
   MPIB_free_pairs(pairs);
   container->finalize(container, comm);
   free(T);
   // allgather the results
   int* recvcounts = (int*)malloc(sizeof(int) * size);
   int* displs = (int*)malloc(sizeof(int) * size);
   int i;
   for (i = 0; i < size; i++) {
      recvcounts[i] = sizeof(MPIB_result) * (size - i - 1);
      displs[i] = i == 0 ? 0 : displs[i - 1] + recvcounts[i - 1];
   }
   MPI_Allgatherv(res, sizeof(MPIB_result) * sendcount, MPI_CHAR, results, recvcounts, displs, MPI_CHAR, comm);
   free(recvcounts);
   free(displs);
   free(res);
}



/* RICO: Implementation of the new functionality of taulop parametr measuring */

/***************************************************************************
 ********************              Overhead              *******************
 ***************************************************************************/

void MPIB_measure_overhead (MPIB_p2p_container* container, MPI_Comm comm, int measure, int mirror, MPIB_msgset msgset, MPIB_precision precision, int *sizes, int nlines, int* count, MPIB_result** results)
{
   int rank;
   MPI_Comm_rank(comm, &rank);

   if (rank == measure || rank == mirror) {

      if (rank == measure) {
         *count = 0;
         *results = NULL;
      }

      //fprintf(stderr, "[MPIB_measure_overhead] Rank:%d\n", rank);fflush(stderr);

      int M = msgset.min_size;
      int c = 0;
      // variables at measure
      double* T = NULL;
      double wtick = 0;
      int stride = msgset.min_stride; //adaptive stride
      int pos = 0;
      int H = msgset.threshold;
      if (rank == measure) {
         // use the same array and wtick value for communication experiments with different message sizes
         T = (double*)malloc(sizeof(double) * precision.max_reps);
         wtick = MPI_Wtick();
      }

      if ((rank == measure) && MPIB_verbose) {
         fprintf(stdout, "\n(taulop) Measuring Overhead parameter ...\n");
         fflush(stdout);
      }

      /*
       In any case, we don't do more than max_size message sizes, but
       with the adaptive approach we also don't iterate more than max_num times
       */
      while (M <= msgset.max_size && !( (msgset.stride == 0) && (c > msgset.max_num))) {

         container->initialize(container, comm, M);
         int stop = 0;
         double sum = 0;
         int reps = 0;
         double ci = 0;
         /*
          This loop performs a number of repetitions with a fixed M. It runs while
          max(min_reps,2) < reps < max_reps) and NOT (ci * reps / sum ) < eps

          COMUNICATION
          */
         while (!stop && reps < precision.max_reps) {

            if (M < H) {  // EAGER

               if (rank == measure) {
                  MPI_Recv(NULL, 0, MPI_CHAR, mirror, 0, comm, MPI_STATUS_IGNORE);
                  T[reps] = MPI_Wtime();
                  container->execute_measure_o_eager(container, comm, M, mirror);
                  container->execute_mirror_o(container, comm, M, mirror);
                  T[reps] = MPI_Wtime() - T[reps];
                  sum += T[reps];
               }
               else {
                  MPI_Send(NULL, 0, MPI_CHAR, measure, 0, comm);
                  container->execute_mirror_o(container, comm, M, measure);
                  container->execute_measure_o_eager(container, comm, M, measure);
               }

            } else {  // RENDEZVOUS

               if (rank == measure) {
                  MPI_Recv(NULL, 0, MPI_CHAR, mirror, 0, comm, MPI_STATUS_IGNORE);
                  usleep(100); // Ensure receiver is ready
                  T[reps] = MPI_Wtime();
                  container->execute_measure_o_rndv(container, comm, M, mirror);
                  T[reps] = MPI_Wtime() - T[reps];
                  sum += T[reps];
               }
               else {
                  MPI_Send(NULL, 0, MPI_CHAR, measure, 0, comm);
                  container->execute_mirror_o(container, comm, M, measure);
               }
            }
            reps++;

            /* PRECISION */
            if (reps >= precision.min_reps && reps > 2) {
               if (rank == measure) {
                  stop = (ci = MPIB_ci(precision.cl, reps, T)) * reps / sum < precision.eps;
               }
               MPI_Bcast(&stop, 1, MPI_INT, measure, comm);
            }

         }

         double t = sum / reps;
         if ((rank == measure) && MPIB_verbose) {
            //double t_adapted = MPIB_adapt_overhead_eager(sum / reps, M);
            fprintf(stdout, "[%d] \t size: %d \t time: %0.12lf \t nreps: %d \t (confidence level: %0.12f)\n",
                    rank,          M,         t,       reps,                 (float)ci);
            fflush(stdout);
         }

         container->finalize(container, comm);

         /* RESULTS */
         c++;
         if (rank == measure) {
            MPIB_result result = (MPIB_result){M, t, wtick, reps, ci};
            *count = c;

            if (pos < c - 1) {
               MPIB_result* tmp = (MPIB_result*)malloc(sizeof(MPIB_result) * c);
               memcpy(tmp, *results, sizeof(MPIB_result) * pos);
               memcpy(&tmp[pos + 1], &(*results)[pos], sizeof(MPIB_result) * (c - 1 - pos));
               free(*results);
               *results = tmp;
            }
            else {
               *results = (MPIB_result*)realloc(*results, sizeof(MPIB_result) * c);
            }
            (*results)[pos] = result;

            /*
             determine the next M - adaptively or with fixed stride:
             if msgset.stride > 0, then use this fixed stride (non-adaptive)
             if msgset.stride == 0, increment M adaptively
             */
            if (msgset.stride == 0) {
               //adaptive M increment :
               do {
                  if (pos > 1 && (MPIB_diff(result, &(*results)[pos - 2]) < msgset.max_diff)) {
                     stride *= 2;
                     M += stride;
                     while (pos < c && (*results)[pos].M < M)
                        pos++;
                  } else {
                     if ((stride / 2) > msgset.min_stride) {
                        stride /= 2;
                        M -= stride;
                     } else {
                        M += stride;
                        while (pos < c && (*results)[pos].M < M)
                           pos++;
                     }
                  }
               } while (pos < c && (*results)[pos].M == M);

            } else if (msgset.input_sz_file != NULL) {
               M = sizes[++pos];

            } else {
               //M += msgset.stride;
               // Avoiding starting in 1 problem.
               M = ((msgset.min_size / msgset.stride) + c) * msgset.stride;
               pos++;
            }

         }
         MPI_Bcast(&M, 1, MPI_INT, measure, comm);
      }
      free(T);
   }
}



/***************************************************************************
 ********************         TRANSFER TIME	             *******************
 ***************************************************************************/
void MPIB_measure_transfert (MPIB_p2p_container* container, MPI_Comm comm, int measure, int mirror, MPIB_msgset msgset, MPIB_precision precision, int *sizes, int nlines, int* count, MPIB_result *overhead, MPIB_result** results, int tau, int isSendRecv)
{
   int rank;
   int source;
   int dest;
   int num_procs;
   MPI_Comm_rank(comm, &rank);
   MPI_Comm_size(comm, &num_procs);

   if (rank >= 0 && rank < num_procs) {
      if (rank == 0) {
         *count = 0;
         *results = NULL;
      }
      int M = msgset.min_size;
      int c = 0;
      // variables at measure
      double* T = NULL;
      double wtick = 0;
      int stride = msgset.min_stride; //adaptive stride
      int H = msgset.threshold;
      int pos = 0;
      // use the same array and wtick value for communication experiments with different message sizes
      T = (double*)malloc(sizeof(double) * precision.max_reps);
      wtick = MPI_Wtick();

      if ((rank == 0) && MPIB_verbose) {
         fprintf(stdout, "\nMeasuring Transfer Time (T) parameter (P=%d, tau=%d, isSendRecv=%d)...\n", num_procs, tau, isSendRecv);
         fflush(stdout);
      }

      /*In any case, we don't do more than max_size message sizes, but
       with the adaptive approach we also don't iterate more than max_num times
       */
      while (M <= msgset.max_size && !( (msgset.stride == 0) && (c > msgset.max_num))) {

         int stop = 0;
         double sum = 0;
         int reps = 0;
         double ci = 0;

         container->initialize(container, comm, M);

         /*
          This loop performs a number of repetitions with a fixed M. It runs while
          max(min_reps,2) < reps < max_reps) and NOT (ci * reps / sum ) < eps
          COMUNICATION
          */
         while (!stop && reps < precision.max_reps) {

            dest   = (rank + 1) % (num_procs);
            source = (rank + num_procs-1) % num_procs;

            MPI_Barrier(comm);
            MPI_Barrier(comm);

            // Time measurement for (P, M)
            if (isSendRecv == 0) { /* TODO: not a good form of doing this.
                                            SendRecv operation to measure parameters is used in
                                              shared memory with P = tau >= 2 processes. Otherwise
                                              (network and shared memory with tau == 1, PingPong
                                              operation is used.
                                    */

               if (rank % 2 == 0) {
                  T[reps] = MPI_Wtime();
                  container->execute_measure_Tm_PingPong(container, comm, M, rank+1);
                  T[reps] = MPI_Wtime() - T[reps];
                  sum += T[reps];
               }
               else { /* mirror */
                  T[reps] = MPI_Wtime();
                  container->execute_mirror_Tm_PingPong(container, comm, M, rank-1);
                  T[reps] = MPI_Wtime() - T[reps];
                  sum += T[reps];
               }

            } else { /* isSendRecv (shared memory and P = tau >= 2 */

               T[reps] = MPI_Wtime();
               container->execute_measure_Tm (container, comm, M, dest, source);
               T[reps] = MPI_Wtime() - T[reps];
               sum += T[reps];
            }

            reps++;


            /* PRECISION */
            if (reps >= precision.min_reps && reps > 2) {
               if (rank == 0) {
                  stop = (ci = MPIB_ci(precision.cl, reps, T)) * reps / sum < precision.eps;
               }
               MPI_Bcast(&stop, 1, MPI_INT, 0, comm);
            }
         }

         // Maximum time
         double t = sum / reps;
         if (rank == 0) {
            MPI_Reduce(MPI_IN_PLACE, &t, 1, MPI_DOUBLE, MPI_MAX, 0, comm);
         } else {
            MPI_Reduce(&t, NULL, 1, MPI_DOUBLE, MPI_MAX, 0, comm);
         }

         if ((rank == 0) && MPIB_verbose) {
            fprintf(stdout, "[%d] \t size: %d \t time: %0.12f \t nreps: %d \t (confidence level: %0.12f)\n", rank, M, t, reps, ci);
            fflush(stdout);
         }

         container->finalize(container, comm);


         /* Results */
         c++;

         if (rank == 0) {
            MPIB_result result = (MPIB_result){M, t, wtick, reps, ci};
            *count = c;
            if (pos < c - 1) {
               MPIB_result* tmp = (MPIB_result*)malloc(sizeof(MPIB_result) * c);
               memcpy(tmp, *results, sizeof(MPIB_result) * pos);
               memcpy(&tmp[pos + 1], &(*results)[pos], sizeof(MPIB_result) * (c - 1 - pos));
               free(*results);
               *results = tmp;
            }
            else {
               *results = (MPIB_result*)realloc(*results, sizeof(MPIB_result) * c);
            }

            (*results)[pos] = result;

            /*
             determine the next M - adaptively or with fixed stride:
             if msgset.stride > 0, then use this fixed stride (non-adaptive)
             if msgset.stride == 0, increment M adaptively
             */

            if (msgset.stride == 0) {
               //adaptive M increment :
               do {
                  if (pos > 1 && (MPIB_diff(result, &(*results)[pos - 2]) < msgset.max_diff)) {
                     stride *= 2;
                     M += stride;
                     while (pos < c && (*results)[pos].M < M)
                        pos++;
                  } else {
                     if ((stride / 2) > msgset.min_stride) {
                        stride /= 2;
                        M -= stride;
                     } else {
                        M += stride;
                        while (pos < c && (*results)[pos].M < M)
                           pos++;
                     }
                  }
               } while (pos < c && (*results)[pos].M == M);

            } else if (msgset.input_sz_file != NULL) {
               M = sizes[++pos];

            } else {
               //M += msgset.stride;
               // Avoiding starting in 1 problem.
               M = ((msgset.min_size / msgset.stride) + c) * msgset.stride;
               pos++;
            }

         }
         MPI_Bcast (&M, 1, MPI_INT, 0, comm);

      }

      free(T);
   }
}






/***************************************************************************
 ********************              GAMMA                 *******************
 ***************************************************************************/
void MPIB_measure_gamma (MPIB_p2p_container* container, MPI_Comm comm, int rank, int op, MPIB_msgset msgset, MPIB_precision precision, int *sizes, int nlines, int* count, MPIB_result** results)
{
   int source;
   int dest;
   int num_procs;
   MPI_Comm_size(comm, &num_procs);

   // Only measurements for Rank = 0 on current machine.
   if (rank == 0) {
         *count = 0;
         *results = NULL;

      int M = msgset.min_size;
      int c = 0;
      // variables at measure
      double* T = NULL;
      double wtick = 0;
      int stride = msgset.min_stride; //adaptive stride
      int H = msgset.threshold;
      int pos = 0;
      // use the same array and wtick value for communication experiments with different message sizes
      T = (double*)malloc(sizeof(double) * precision.max_reps);
      wtick = MPI_Wtick();

      if (MPIB_verbose) {
         fprintf(stdout, "\nMeasuring Gamma computation time (g) parameter (op: %d) ...\n", op);
         fflush(stdout);
      }

      /*In any case, we don't do more than max_size message sizes, but
       with the adaptive approach we also don't iterate more than max_num times
       */
      while (M <= msgset.max_size && !( (msgset.stride == 0) && (c > msgset.max_num))) {

         int stop = 0;
         double sum = 0;
         int reps = 0;
         double ci = 0;

         container->initialize(container, comm, M);

         void *a = NULL;
         void *b = NULL;

         /*
         if ((op >= MAX_I) && (op < MAXLOC_I)) {
           a = (int *) malloc (M);
           b = (int *) malloc (M);
           fprintf(stdout, "RESERVADOS %d bytes para OP %d con sizeof %d\n", M, op, 1);
         } else if ((op >= MAXLOC_I) && (op <= MINLOC_I)) {
           a = (ompi_op_predefined_2int_t *) malloc (M * sizeof(ompi_op_predefined_2int_t));
           b = (ompi_op_predefined_2int_t *) malloc (M * sizeof(ompi_op_predefined_2int_t));
           fprintf(stdout, "RESERVADOS %d bytes para OP %d con sizeof %d\n", M * sizeof(ompi_op_predefined_2int_t), op, sizeof(ompi_op_predefined_2int_t));
         } else if ((op >= MAX_R) && (op < MAXLOC_R)) {
           a = (float *) malloc (M);
           b = (float *) malloc (M);
           fprintf(stdout, "RESERVADOS %d bytes para OP %d r con sizeof %d\n", M, op, 1);
         } else if ((op >= MAXLOC_R) && (op < MINLOC_R)) {
           a = (ompi_op_predefined_float_int_t *) malloc (M * sizeof(ompi_op_predefined_float_int_t));
           b = (ompi_op_predefined_float_int_t *) malloc (M * sizeof(ompi_op_predefined_float_int_t));
           fprintf(stdout, "RESERVADOS %d bytes para OP %d con sizeof %d\n", M * sizeof(ompi_op_predefined_float_int_t), op, sizeof(ompi_op_predefined_float_int_t));
         } else {
           fprintf(stderr, "ERROR: no operation defined to measure Gamma.");
           exit(1);
         }
         */

         /* We count on sizeof float and int = 4. */
         if (M < sizeof(int)) {
            M = sizeof(int);
         }

         if ((op >= MAX_I) && (op < MAXLOC_I)) {
           a = (int *) malloc (M);
           b = (int *) malloc (M);
         } else if ((op >= MAXLOC_I) && (op <= MINLOC_I)) {
           a = (ompi_op_predefined_2int_t *) malloc (M * 2);
           b = (ompi_op_predefined_2int_t *) malloc (M * 2);
           //fprintf(stdout, "RESERVADOS %d bytes para OP %d con sizeof %d\n", M * 2, op, sizeof(ompi_op_predefined_2int_t));
         } else if ((op >= MAX_R) && (op < MAXLOC_R)) {
           a = (float *) malloc (M);
           b = (float *) malloc (M);
         } else if ((op >= MAXLOC_R) && (op <= MINLOC_R)) {
           a = (ompi_op_predefined_float_int_t *) malloc (M * 2);
           b = (ompi_op_predefined_float_int_t *) malloc (M * 2);
           //fprintf(stdout, "RESERVADOS %d bytes para OP %d con sizeof %d\n", M * 2, op, sizeof(ompi_op_predefined_float_int_t));
         } else {
           fprintf(stderr, "ERROR: no operation defined to measure Gamma.");
           exit(1);
         }

         /*
          This loop performs a number of repetitions with a fixed M. It runs while
          max(min_reps,2) < reps < max_reps) and NOT (ci * reps / sum ) < eps
          COMUNICATION
          */
         while (!stop && reps < precision.max_reps) {

              T[reps] = MPI_Wtime();
              container->execute_measure_Gamma(container, comm, M, op, a, b);
              T[reps] = MPI_Wtime() - T[reps];
              sum += T[reps];



            reps++;


            /* PRECISION */
            if (reps >= precision.min_reps && reps > 2) {
               if (rank == 0) {
                  stop = (ci = MPIB_ci(precision.cl, reps, T)) * reps / sum < precision.eps;
               }
               //MPI_Bcast(&stop, 1, MPI_INT, 0, comm);
            }
         }

         free(a);
         free(b);

         // Average time
         double t = sum / reps;

         if (MPIB_verbose) {
            fprintf(stdout, "[%d] \t size: %d \t Op: %d \t time: %0.12f \t nreps: %d \t (confidence level: %0.12f)\n", rank, M, op, t, reps, ci);
            fflush(stdout);
         }

         container->finalize(container, comm);


         /* Results */
         c++;

            MPIB_result result = (MPIB_result){M, t, wtick, reps, ci};
            *count = c;
            if (pos < c - 1) {
               MPIB_result* tmp = (MPIB_result*)malloc(sizeof(MPIB_result) * c);
               memcpy(tmp, *results, sizeof(MPIB_result) * pos);
               memcpy(&tmp[pos + 1], &(*results)[pos], sizeof(MPIB_result) * (c - 1 - pos));
               free(*results);
               *results = tmp;
            }
            else {
               *results = (MPIB_result*)realloc(*results, sizeof(MPIB_result) * c);
            }

            (*results)[pos] = result;

            /*
             determine the next M - adaptively or with fixed stride:
             if msgset.stride > 0, then use this fixed stride (non-adaptive)
             if msgset.stride == 0, increment M adaptively
             */

            if (msgset.stride == 0) {
               //adaptive M increment :
               do {
                  if (pos > 1 && (MPIB_diff(result, &(*results)[pos - 2]) < msgset.max_diff)) {
                     stride *= 2;
                     M += stride;
                     while (pos < c && (*results)[pos].M < M)
                        pos++;
                  } else {
                     if ((stride / 2) > msgset.min_stride) {
                        stride /= 2;
                        M -= stride;
                     } else {
                        M += stride;
                        while (pos < c && (*results)[pos].M < M)
                           pos++;
                     }
                  }
               } while (pos < c && (*results)[pos].M == M);

            } else if (msgset.input_sz_file != NULL) {
               M = sizes[++pos];

            } else {
               //M += msgset.stride;
               // Avoiding starting in 1 problem.
               M = ((msgset.min_size / msgset.stride) + c) * msgset.stride;
               pos++;
            }

         //MPI_Bcast (&M, 1, MPI_INT, 0, comm);

      }

      free(T);
   }
}
