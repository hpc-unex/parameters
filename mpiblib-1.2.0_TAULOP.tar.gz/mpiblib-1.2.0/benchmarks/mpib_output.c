#include "mpib_output.h"
#include <stdio.h>

int MPIB_verbose = 0;

void MPIB_print_processors(MPI_Comm comm)
{
   int rank;
   MPI_Comm_rank(comm, &rank);
   char name[MPI_MAX_PROCESSOR_NAME];
   int len;
   MPI_Get_processor_name(name, &len);
   if (rank == 0)
   {
      int size;
      MPI_Comm_size(comm, &size);

      printf("#P\t%d\n", size);
      printf("#rank\tprocessor\n");
      printf("#%d\t%s\n", rank, name);
      int i;
      for (i = 1; i < size; i++)
      {
         MPI_Recv(&rank, 1, MPI_INT, i, 0, comm, MPI_STATUS_IGNORE);
         MPI_Recv(name, MPI_MAX_PROCESSOR_NAME, MPI_CHAR, i, 0, comm, MPI_STATUS_IGNORE);
         printf("#%d\t%s\n", rank, name);
      }
      printf("#\n");
   }
   else
   {
      MPI_Send(&rank, 1, MPI_INT, 0, 0, comm);
      MPI_Send(name, MPI_MAX_PROCESSOR_NAME, MPI_CHAR, 0, 0, comm);
   }
}

/* RICO */
void MPIB_print_processors_file(MPI_Comm comm, FILE *f)
{
   int rank;
   MPI_Comm_rank(comm, &rank);
   char name[MPI_MAX_PROCESSOR_NAME];
   int len;
   MPI_Get_processor_name(name, &len);
   if (rank == 0)
   {
      int size;
      MPI_Comm_size(comm, &size);

      fprintf(f, "#P\t%d\n", size);
      fprintf(f, "#rank\tprocessor\n");
      fprintf(f, "#%d\t%s\n", rank, name);
      int i;
      for (i = 1; i < size; i++)
      {
         MPI_Recv(&rank, 1, MPI_INT, i, 0, comm, MPI_STATUS_IGNORE);
         MPI_Recv(name, MPI_MAX_PROCESSOR_NAME, MPI_CHAR, i, 0, comm, MPI_STATUS_IGNORE);
         fprintf(f, "#%d\t%s\n", rank, name);
      }
      fprintf(f, "#\n");
   }
   else
   {
      MPI_Send(&rank, 1, MPI_INT, 0, 0, comm);
      MPI_Send(name, MPI_MAX_PROCESSOR_NAME, MPI_CHAR, 0, 0, comm);
   }
}


void MPIB_print_precision(MPIB_precision precision)
{
   printf("#Precision\n");
   printf("#min_reps\t%d\n", precision.min_reps);
   printf("#max_reps\t%d\n", precision.max_reps);
   printf("#cl\t\t%le\n", precision.cl);
   printf("#eps\t\t%le\n", precision.eps);
   printf("#\n");
}

/* RICO: replaced
 void MPIB_print_msgset(MPIB_msgset msgset)
 {
 printf("#Message set\n");
 printf("#min_size\t%d\n", msgset.min_size);
 printf("#max_size\t%d\n", msgset.max_size);
 printf("#stride\t\t%d\n", msgset.stride);
 printf("#max_diff\t%le\n", msgset.max_diff);
 printf("#min_stride\t%d\n", msgset.min_stride);
 printf("#max_num\t%d\n", msgset.max_num);
 printf("#\n");
 }
 */

void MPIB_print_result_th() {
   printf("#msg\ttime\t\twtick\treps\tci\n");
}

void MPIB_print_result_tr(MPIB_result result) {
   printf("%d\t%le\t%d\t%d\t%le\n",
          result.M,
          result.T,
          result.wtick < result.T,
          result.reps,
          result.ci
          );
   fflush(stdout);
}

void MPIB_print_coll(const char* operation, const char* timing)
{
   printf("#operation\t%s\n", operation);
   printf("#timing\t\t%s\n", timing);
   printf("#\n");
}

void MPIB_print_p2p(int parallel)
{
   printf("#%s\n", parallel ? "parallel" : "sequential");
   printf("#\n");
}

void MPIB_print_p2p_table(int M, int parallel, MPIB_precision precision, int n, MPIB_result* results)
{
   printf("#msg\t\t%d\n", M);
   MPIB_print_p2p(parallel);
   MPIB_print_precision(precision);
   printf
   (
"#p2p\t\
time\t\t\
wtick\t\
reps\t\
ci\n"
    );
   int i, index;
   for(i = 0, index = 0; i < n - 1; i++)
   {
      int j;
      for(j = i + 1; j < n; j++, index++)
         printf
         (
"%d-%d\t\
%le\t\
%d\t\
%d\t\
%le\n",
          i, j,
          results[index].T,
          results[index].wtick < results[index].T,
          results[index].reps,
          results[index].ci
          );
   }
   fflush(stdout);
}

void MPIB_print_p2p_th(int parallel, MPIB_precision precision, int n)
{
   printf("#%s\n", parallel ? "parallel" : "sequential");
   MPIB_print_precision(precision);
   printf("#\t");
   int i, index;
   for(i = 0, index = 0; i < n - 1; i++)
   {
      int j;
      for(j = i + 1; j < n; j++, index++)
         printf("%d-%d\t\t\t\t\t\t", i, j);
   }
   printf("\n#msg\t");
   for(i = 0, index = 0; i < n - 1; i++)
   {
      int j;
      for(j = i + 1; j < n; j++, index++)
         printf
         (
"time\t\t\
wtick\t\
reps\t\
ci\t\t"
          );
   }
   printf("\n");
}

void MPIB_print_p2p_tr(int M, int n, MPIB_result* results)
{
   printf("%d\t", M);
   int i, index;
   for(i = 0, index = 0; i < n - 1; i++)
   {
      int j;
      for(j = i + 1; j < n; j++, index++)
         printf
         (
"%le\t\
%d\t\
%d\t\
%le\t",
          results[index].T,
          results[index].wtick < results[index].T,
          results[index].reps,
          results[index].ci
          );
   }
   printf("\n");
   fflush(stdout);
}

void MPIB_print_coll_th(const char* operation, const char* timing, int n, int root, MPIB_precision precision)
{
   printf("#nodes\t\t%d\n", n);
   printf("#root\t\t%d\n", root);
   MPIB_print_coll(operation, timing);
   MPIB_print_precision(precision);
   printf
   (
"#msg\t\
time\t\t\
wtick\t\
reps\t\
ci\n"
    );
}

void MPIB_print_coll_tr(int M, MPIB_result result)
{
   printf
   (
"%d\t\
%le\t\
%d\t\
%d\t\
%le\n",
    M,
    result.T,
    result.wtick < result.T,
    result.reps,
    result.ci
    );
   fflush(stdout);
}


/* RICO: print taulop results for overhead and transfer time in files */

void MPIB_print_result_overhead_header(FILE *f) {
   fprintf(f,"#size\to(m)\n");
   fflush(stdout);
}


void MPIB_print_result_overhead_value(MPIB_result result,FILE *f) {
   fprintf(f,"%d\t%0.12f\n",
           result.M,
           result.T
           //result.wtick < result.T,
           //result.reps,
           //result.ci
           );
   fflush(stdout);
}


void MPIB_print_transfert_header (FILE *f, int tau) {

   fprintf(f,"#size\t");
   for (int t = 1; t <= tau; t++) {
      fprintf(f," T(m,%d)\t", t);
   }
   fprintf(f,"\n");
   fflush(stdout);

   return;
}


void MPIB_print_result_transfert_value(int tau, int count, MPIB_result arr[count][tau], FILE *f) {

   for (int m = 0; m < count; m++) {
      fprintf(f, "%d\t", arr[m][0].M);
      for (int p = 0; p < tau; p++) {
         fprintf(f, "%0.12f\t", arr[m][p].T);
      }
      fprintf(f, "\n");
   }
   return;
}

void MPIB_print_msgset(MPIB_msgset msgset, MPIB_precision precision, FILE *f)
{
   //printf("#Message set\n");
   fprintf(f,"#tau\t%d\n", msgset.tau);
   fprintf(f,"#m\t%d\n", msgset.min_size);
   fprintf(f,"#M\t%d\n", msgset.max_size);
   fprintf(f,"#S\t%d\n", msgset.stride);
   fprintf(f,"#d\t%0.6f\n", msgset.max_diff);
   fprintf(f,"#s\t%d\n", msgset.min_stride);
   fprintf(f,"#o\t%s\n", msgset.overhead_file);
   fprintf(f,"#t\t%s\n", msgset.transfertime_file);
   //fprintf(f,"#t\t%d\n", msgset.max_tau);
   fprintf(f,"#b\t%s\n", msgset.parameter);
   //fprintf(f,"#f\t%s\n", msgset.input_file_o);
   //fprintf(f,"#l\t%s\n", msgset.input_file_l);
   fprintf(f,"#H\t%d\n", msgset.threshold);
   fprintf(f,"#C\t%s\n", msgset.network_type);
   fprintf(f,"#n\t%d\n", msgset.max_num);
   fprintf(f,"#min_reps\t%d\n", precision.min_reps);
   fprintf(f,"#max_reps\t%d\n", precision.max_reps);
   fprintf(f,"#cl\t\t%0.6f\n", precision.cl);
   fprintf(f,"#eps\t\t%0.6f\n", precision.eps);
}



void MPIB_print_gamma_header (FILE *f, int max_ops, int count) {

  enum ops {MAX_I, MIN_I, SUM_I, PROD_I, LAND_I, LOR_I, LXOR_I, BAND_I, BOR_I, BXOR_I, MAXLOC_I, MINLOC_I,
         MAX_R, MIN_R, SUM_R, PROD_R, /*LAND_R, LOR_R, LXOR_R, BAND_R, BOR_R, BXOR_R, */MAXLOC_R, MINLOC_R };

  char *ops_s[] = {"MAX_I", "MIN_I", "SUM_I", "PROD_I", "LAND_I", "LOR_I", "LXOR_I", "BAND_I", "BOR_I", "BXOR_I", "MAXLOC_I", "MINLOC_I",
         "MAX_R", "MIN_R", "SUM_R", "PROD_R", /*LAND_R, LOR_R, LXOR_R, BAND_R, BOR_R, BXOR_R, */"MAXLOC_R", "MINLOC_R"};

   fprintf(f,"#m\t%d\n", count);
   fprintf(f,"#max_ops\t%d\n", max_ops);
   
   fprintf(f,"#size\t");
   for (int op = 0; op < max_ops; op++) {
      fprintf(f,"%s\t", ops_s[op]);
   }
   fprintf(f,"\n");
   fflush(stdout);

   return;
}


void MPIB_print_result_gamma_value(int max_ops, int count, MPIB_result arr[count][max_ops], FILE *f) {

   for (int m = 0; m < count; m++) {
      fprintf(f, "%d\t", arr[m][0].M);
      for (int op = 0; op < max_ops; op++) {
         fprintf(f, "%0.12f\t", arr[m][op].T);
      }
      fprintf(f, "\n");
   }
   return;
}
