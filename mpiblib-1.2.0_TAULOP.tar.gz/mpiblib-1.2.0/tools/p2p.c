/*!
 * \page p2p P2P benchmark
 * Performs adaptive p2p benchmark between a pair of processors 0-1.
 * Arguments are described in \ref getopt.
 *
 * \b Example:
 * \code
 * $ mpirun -n 2 p2p -m 1024 -M 2049 > p2p.out
 * \endcode
 * will benchmark the p2p communication between 2 processes for
 * message sizes of 1024 and 2048 bytes
 *
 * \b p2p.plot draws the graph of the execution time (sec) against message size (kb).
 * - input: p2p.out
 * - output: p2p.eps (0-1 with error bars)
 *
 * Using the gnuplot script:
 * \code
 * $ gnuplot p2p.plot
 * \endcode
 */

#include "config.h"

#include <getopt.h>
#include <malloc.h>
#include <string.h>
#include <stdlib.h>

#include "benchmarks/mpib.h"
#include "p2p/mpib_p2p.h"


/* RICO:  Results */
void print_results_overhead (int count, MPIB_result* results, FILE *f){

   MPIB_print_result_overhead_header(f);

   for (int i = 0; i < count; i++){
      MPIB_print_result_overhead_value(results[i],f);
   }
}


void print_results_transfertime (int count, int num_procs, MPIB_result arr[count][num_procs], FILE *f) {

   MPIB_print_transfert_header(f, num_procs);
   MPIB_print_result_transfert_value(num_procs, count, arr, f);
}



void print_results_gamma (int count, int max_ops, MPIB_result arr[count][max_ops], FILE *f) {

   MPIB_print_gamma_header(f, max_ops, count);
   MPIB_print_result_gamma_value(max_ops, count, arr, f);
}






int measurements (int argc, char** argv) {

   //RICO: MPI_Init(&argc, &argv);

   //MPIB_Init(&argc, &argv);
   MPI_Comm comm = MPI_COMM_WORLD;

   int exit;
   int p2p_type;
   int parallel = 0; /// not used at the moment
   int proc_num_spawned = 0;
   MPIB_getopt_help_default(&exit);
   MPIB_getopt_p2p_default(&parallel, &p2p_type, &proc_num_spawned);
   MPIB_msgset msgset;
   MPIB_getopt_msgset_default(&msgset);
   // if we want adaptive message sizes, we should do: msgset.stride = 0;
   MPIB_precision precision;
   MPIB_getopt_precision_default(&precision);

   int rank;
   int num_procs;
   MPI_Comm_rank (comm, &rank);
   MPI_Comm_size (comm, &num_procs);

   if (rank == 0) {
      int c;
      char options[256] = "i:P:";
      strcat(options, MPIB_getopt_help_options());
      strcat(options, MPIB_getopt_msgset_options());
      strcat(options, MPIB_getopt_precision_options());
      strcat(options, MPIB_getopt_p2p_options());
      while ((c = getopt(argc, argv, options)) != -1) {
         MPIB_getopt_help_optarg(c, "p2p", &exit);
         MPIB_getopt_msgset_optarg(c, &msgset);
         MPIB_getopt_precision_optarg(c, &precision);
         MPIB_getopt_p2p_optarg(c, &parallel, &p2p_type, &proc_num_spawned);
      }
   }
   MPIB_getopt_help_bcast(&exit, 0, comm);
   if (exit) {
      //RICO: MPI_Finalize();
      return 0;
   }
   MPIB_getopt_msgset_bcast(&msgset, 0, comm);
   MPIB_getopt_precision_bcast(&precision, 0, comm);
   MPIB_getopt_p2p_bcast(&parallel, &p2p_type, &proc_num_spawned, 0, comm);



   /* RICO: starting measurements: */

   MPIB_p2p_container* container = MPIB_roundtrip_container_alloc();
   int count = 0;
   MPIB_result* results = NULL;
   double time = MPI_Wtime();


   /* RICO: configuration arguments */
   int param_type = MPIBlib;  // default to MPIBlib measurements.
   if (rank == 0) {
      if (! strcasecmp("taulop", msgset.parameter)) {
         param_type = taulop;
      }
   }
   MPI_Bcast(&param_type, 1, MPI_INT, 0, comm);

   if (param_type == taulop) {
      /* RICO: Parameter measurement: both, overhead and transfer-times */

      /* If SHM network we have special cases to control */
      int network_shm = 0;
      if (! strcasecmp("SHM", msgset.network_type)) {
         network_shm = 1;
      }
      MPI_Bcast(&network_shm, 1, MPI_INT, 0, comm);



      FILE *f_overhead = NULL;
      FILE *f_transfert = NULL;
      FILE *f_gamma = NULL;

      // RICO: get the file names to output results and open:
      if ((f_overhead = fopen(msgset.overhead_file, "w")) == NULL) {
         fprintf(stderr, "ERROR: unable to create overhead file <%s>\n", msgset.overhead_file);
         return -1;
      }

      if ((f_transfert = fopen(msgset.transfertime_file, "w")) == NULL) {
         fprintf(stderr, "ERROR: unable to create transfer-times file <%s>\n", msgset.transfertime_file);
         return -1;
      }


      if (rank == 0)
      	printf("#p2p adaptive benchmark 0-1\n#\n");
      MPIB_print_processors(comm);

      /* RICO: */
      MPIB_print_processors_file(comm, f_overhead);
      MPIB_print_processors_file(comm, f_transfert);

      if (rank == 0) {
         MPIB_print_msgset(msgset, precision, f_overhead);
         MPIB_print_msgset(msgset, precision, f_transfert);
         MPIB_print_precision(precision);
      }

      if (p2p_type == 1)
         p2p_init(comm, proc_num_spawned);


      /* RICO: test for sizes text file and adjust parameters */
      int *sizes = NULL;
      int nlines = 0;
      FILE *isz;

      if (msgset.input_sz_file != NULL) {

         if (rank == 0) {
            fprintf(stdout, "<sizes> File: %s\n", msgset.input_sz_file);

            isz = fopen(msgset.input_sz_file, "r");

            if (!isz) {
               fprintf(stderr, "ERROR: opening <sizes> file %s\n", msgset.input_sz_file);
               fflush(stderr);
               return -1;
            }

            ssize_t read;
            size_t  len;
            char *  line = NULL;

            while ((read = getline(&line, &len, isz)) != -1) {
               nlines++;
            }
            fseek(isz, 0, SEEK_SET);

            nlines++;
            sizes = (int *) malloc (sizeof(int) * nlines);
            nlines = 0;
            while ((read = getline(&line, &len, isz)) != -1) {
               sizes[nlines++] = atoi(line);
            }
            sizes[nlines] = sizes[nlines-1] + 1;  // One more size

            fclose(isz);

            msgset.max_size = sizes[nlines-1];
            msgset.min_size = sizes[0];
         }

         MPI_Bcast(&nlines, 1, MPI_INT, 0, comm);

         if (rank != 0) {
            sizes = (int *) malloc (sizeof(int) * nlines);
         }

         MPI_Bcast(sizes, nlines, MPI_INT, 0, comm);
      }

      MPI_Bcast(&msgset.max_size, 1, MPI_INT, 0, comm);
      MPI_Bcast(&msgset.min_size, 1, MPI_INT, 0, comm);

      int max_tau = msgset.tau;
      MPI_Bcast(&max_tau, 1, MPI_INT, 0, comm);



      //fprintf(stderr, "[%d] FIN sizes file: %s  MIN:%d  MAX:%d\n", rank, msgset.input_sz_file, msgset.min_size, msgset.max_size); fflush(stderr);


      /* ======================================
       * ========	    OVERHEAD       =========
       * ======================================
       */

      MPI_Comm comm = MPI_COMM_WORLD;

      MPIB_result* results_o = NULL;
      MPIB_measure_overhead(container, comm, 0, 1, msgset, precision, sizes, nlines, &count, &results_o);

      if (rank == 0) {
         print_results_overhead(count, results_o, f_overhead);
      }


      /* ======================================
       * ========	    GAMMA           =========
       * ======================================
       */

      if (network_shm) {       // Measure only with SHM network
         
        MPI_Comm comm_self = MPI_COMM_SELF;
        const int max_ops = 18; // By hand.

        MPIB_result arr_G[count][max_ops];

        MPIB_result* results_G = NULL;

        for(int m = 0; m < count; m++) {
           for(int op = 0; op < max_ops; op++){
              arr_G[m][op].T = 0.0;
              arr_G[m][op].M = 0;
           }
        }

        if(rank == 0) {
           
           if ((f_gamma = fopen(msgset.gamma_file, "w")) == NULL) {
              fprintf(stderr, "ERROR: unable to create gamma file <%s>\n", msgset.gamma_file);
              return -1;
           }


          for(int op = 0; op < max_ops; op++) {

             MPIB_measure_gamma(container, comm_self, 0, op, msgset, precision, sizes, nlines, &count, &results_G);

             for (int i = 0; i < count; i++) {
                arr_G[i][op].M = results_G[i].M;
                arr_G[i][op].T = results_G[i].T;
             }
          }

          print_results_gamma(count, max_ops, arr_G, f_gamma);
           
           fclose(f_gamma);
        }

      }

      /* ======================================
       * ========	     TRANSFER       =========
       * ======================================
       */

      MPI_Comm new_comm;
      MPI_Group group_world;
      int proc = 0;

      MPIB_result arr_T[count][max_tau];

      for(int m = 0; m < count; m++) {
         for(int t = 0; t < max_tau; t++){
            arr_T[m][t].T = 0.0;
            arr_T[m][t].M = 0;
         }
      }

      MPIB_result* results_T = NULL;

      for(int tau = 1; tau <= max_tau; tau++) {

         /* TODO: This is not a good form of doing this:
              We have different forms of measuring parameters in SHM and NET:
               SHM) If tau=1 we need two processes to measure a PingPong time.
                    Otherwise (tau >= 2) we need P=tau processes in Sendrecv
               NET) We need always P=tau * 2 processes to launch concurrent
                    PingPongs with processes in two different nodes of the machine
          */

         int p = 0;
         int isSendRecv = 0; /* SendRecv is used if SHM communication channel and tau >= 2 */

         if (network_shm) {
            /* We measure transfer time for increasing number of concurrent
               transmissions (tau). The number of processes is set according to tau:
               for tau == 1, number of processes are P=2, and measure is in a PingPong
               for tau >= 2, number of processes are P=tau, and measure is in a Ring
             */
            p = tau;
            if (tau == 1) {
               p = 2;
            } else {
               isSendRecv = 1;
            }

         } else { /* network_type != SHM */

            p = tau * 2;

         }

         //if (rank == 0) fprintf(stderr, "[MPIB_measure_transfert  rank %d] P = %d  tau = %d  isSendRecv = %d network_type=%s\n", rank, p, tau, isSendRecv, msgset.network_type); fflush(stderr);



         //color = rank / p;
         //MPI_Comm_split (comm, color, rank, &new_comm);

         MPI_Group group, new_group;
         MPI_Comm_group (comm, &group);
         int *ranks_v = (int *) malloc (sizeof(int) * p);
         for (int i = 0; i < p; i++) {
            ranks_v[i] = i;
         }
         MPI_Group_incl(group, p, ranks_v, &new_group);
         MPI_Comm_create(comm, new_group, &new_comm);

         //Solo procesos elegidos(1,2,3,..,n)
         //if (color == 0) {
         if (new_comm != MPI_COMM_NULL) {

            MPIB_measure_transfert(container, new_comm, 0, 1, msgset, precision, sizes, nlines+1, &count, results_o, &results_T, tau, isSendRecv);

            if(rank == 0) {
               for (int i = 0; i < count; i++) {
                  arr_T[i][tau-1].M = results_T[i].M;
                  arr_T[i][tau-1].T = results_T[i].T;
               }
            }

            if(rank == 0) {
               proc++;
            }
         }

         free (ranks_v);
         if (new_comm != MPI_COMM_NULL) {
            MPI_Comm_free(&new_comm);
         }
         MPI_Group_free(&new_group);
      }
      if (rank == 0) {
         //print_results_transfertime (count, num_procs, arr_T, f_transfert);
         print_results_transfertime (count, max_tau, arr_T, f_transfert);
      }

      if (rank == 0) {
         fclose(f_overhead);
         fclose(f_transfert);
      }

      /* Defult: timing by mpiblib */
   } else {

      if (rank == 0) {
         MPIB_print_precision(precision);
      }

      if (p2p_type == 1)
         p2p_init(comm, proc_num_spawned);

      /* RICO: remove this measurement */
      MPIB_measure_p2p_msgset(container, comm, 0, 1, msgset, precision, &count, &results);
      if (rank == 0) {
         printf("#total benchmarking time: %le\n#\n", MPI_Wtime() - time);
         MPIB_print_result_th();
         int i;
         for (i = 0; i < count; i++)
            MPIB_print_result_tr(results[i]);
      }
      free(results);
   }

   MPIB_roundtrip_container_free(container);

   if (p2p_type == 1)
      p2p_finalize();

   // RICO: MPI_Finalize();
   // RICO: close output file.

   return 0;
}

// RICO: Put main appart
int main(int argc, char** argv) {

   MPI_Init(&argc, &argv);
   measurements(argc, argv);

   MPI_Finalize();
   return 0;
}
