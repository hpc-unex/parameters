#!/bin/bash

export LD_LIBRARY_PATH=/home/jarico/gsl-2.7.1/.libs:$LD_LIBRARY_PATH

export PATH=$HOME/openmpi/bin:$PATH

DATE=`date +"%m_%d_%Y_%H_%M"`

MPILIB="$HOME/mpiblib-1.2.0"
BENCHMARK="$MPILIB/tools/p2p"
OUTPUT="$PWD/metropolis_output_$DATE.txt"
touch $OUTPUT

echo "mpiblib in: $MPIBLIB"
echo "benchmark:  $BENCHMARK"

echo "Output in:  $OUTPUT"


##################################################
##########      Parameters:
##################################################

### File sizes.txt
#SIZES_F="-z $MPILIB/taulop/scripts/sizes.sz"
SIZES_F="-z $MPILIB/taulop/metropolis/07/sizes_short.sz"
#SIZES_F=""

###  m
m="-m 1"

###  M
M="-M 262144"

###  S
S="-S 65536"

###  C - network label
NETW="SHM"
C="-C $NETW"

###  overhead output file
o="-o overhead_$NETW.txt"

###  transfer time output file
t="-t transfertime_$NETW.txt"

###  gamma computation measurements
g="-g gamma.txt"

###  H - threshold
H="-H 131072"

###  c - confidence level
c="-c 0.995"

###  e - error
e="-e 0.01"

###  r - min. repetitions
r="-r 500"

###  R - max. repetitions
R="-R 8000"

###  T - max. concurrent transmissions
T='-T 8'

###  v - verbose
v="-v"
#v=""

###  Processes per node. Depends on tau.
# For shared memory, we need P=tau processes (except for tau==1, that we need P=2)
# For network, we use two nodes with pairs of processes sending and receiving in a PingPong.
#              Hence, we need P=tau x 2 processes.
P_NODE=8
P_2NODES=16


##################################################
##########      MEASUREMENTS
##################################################

###   SHM

START=$(date +%s)

echo -e "Shared Memory (SHM)"
echo -e "mpiexec  -n $P_NODE --map-by core --bind-to core -report-bindings --display-map  -nooversubscribe  $BENCHMARK -b taulop $m $M $S $C $o $t $g $SIZES_F $H $T $c $e $r $R $v >> $OUTPUT"

# Two processes in adjacent cores for overhead, P=8 for shared memory parameters.
mpiexec -n $P_NODE --map-by core --bind-to core -report-bindings --display-map  -nooversubscribe  $BENCHMARK -b taulop $m $M $S $C $o $t $g $SIZES_F $H $T $c $e $r $R $v >> $OUTPUT

END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Shared memory (SHM) took $DIFF seconds"



###   TCP

########## Parameters:

###  C - network label
NETW="TCP"
C="-C $NETW"

###  overhead output file
o="-o overhead_$NETW.txt"

###  transfer time output file
t="-t transfertime_$NETW.txt"


START=$(date +%s)

echo -e "Network (TCP)"
echo -e "mpiexec --mca btl tcp,self -n $P_2NODES --map-by node --bind-to core -report-bindings --display-map  -nooversubscribe  $BENCHMARK -b taulop $m $M $S $C $o $t $SIZES_F $H $T $c $e $r $R $v >> $OUTPUT"

# Processes in two nodes in a ring.
mpiexec --mca btl tcp,self -n $P_2NODES -hostfile hosts --map-by node --bind-to core -report-bindings --display-map  -nooversubscribe  $BENCHMARK -b taulop $m $M $S $C $o $t $SIZES_F $H $T $c $e $r $R $v >> $OUTPUT

END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Network (TCP) took $DIFF seconds"





###   IB

########## Parameters:

###  C - network label
NETW="IB"
C="-C $NETW"

###  overhead output file
o="-o overhead_$NETW.txt"

###  transfer time output file
t="-t transfertime_$NETW.txt"


START=$(date +%s)

echo -e "Network (IB)"
echo -e "mpiexec --mca btl_openib_allow_ib 1  -n $P_2NODES --map-by node --bind-to core -report-bindings --display-map  -nooversubscribe  $BENCHMARK -b taulop $m $M $S $C $o $t $SIZES_F $H $T $c $e $r $R $v >> $OUTPUT"

# Processes in a ring in two nodes.
mpiexec  --mca btl_openib_allow_ib 1 -n $P_2NODES -hostfile hosts --map-by node --bind-to core -report-bindings --display-map  -nooversubscribe  $BENCHMARK -b taulop $m $M $S $C $o $t $SIZES_F $H $T $c $e $r $R $v >> $OUTPUT

END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Network (IB) took $DIFF seconds"
